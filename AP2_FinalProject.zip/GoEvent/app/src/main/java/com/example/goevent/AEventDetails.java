package com.example.goevent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AEventDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_details);
    }
}