package com.example.goevent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AEventOptions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_options);
    }
}