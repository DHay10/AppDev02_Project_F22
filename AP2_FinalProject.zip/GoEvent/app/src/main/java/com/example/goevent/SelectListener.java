package com.example.goevent;

public interface SelectListener {
    void onItemClicked(Event event);
}
